#include "SIM_router.h"
//#include "SIM_router_area.h"
double  power_main(double, double, double,double,double,double);
double link_power(double);
void routerArea();

