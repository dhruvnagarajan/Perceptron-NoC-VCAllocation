Project files for Microsoft Visual C++ version 7.1 are provided in the 
subdidrectory containing each of these examples.

Each project file has the correct settings to build the example in either
Debug or Release modes.

The project files assume an environment variable name SYSTEMC exists and 
contains the path to the mscv71 subdirectory that is part of the SystemC 2.2
installation (e.g. C:\apps\systemc-2.2\msvc71).